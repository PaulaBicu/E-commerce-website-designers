
-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_products` varchar(100) NOT NULL,
  `price_products` varchar(11) NOT NULL,
  `image_products` text NOT NULL,
  `qty` int(10) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `id_products` int(11) NOT NULL,
  `usersId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `name_products`, `price_products`, `image_products`, `qty`, `total_price`, `id_products`, `usersId`) VALUES
(77, 'Logo - Ferma ', '150', 'https://99designs-blog.imgix.net/blog/wp-content/uploads/2017/12/attachment_76013383.jpg?auto=format&q=60&fit=max&w=930', 1, '150', 12, 4),
(78, 'Fanart - Genshin Im', '150', 'https://upload-os-bbs.hoyolab.com/upload/2021/02/26/1015537/d16c2a258acd96a04623692308dd288d_9193833608002301649.jpg?x-oss-process=image/resize,s_740/quality,q_80/auto-orient,0/interlace,1/format,jpg', 1, '150', 19, 4);
