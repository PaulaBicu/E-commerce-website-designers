
-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `city` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `pmode` varchar(50) NOT NULL,
  `products` varchar(255) NOT NULL,
  `amount_paid` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usersId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usersId` (`usersId`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `email`, `phone`, `city`, `address`, `pmode`, `products`, `amount_paid`, `date`, `usersId`) VALUES
(11, 'Paula Bicu', 'alina_bicu04@yahoo.com', '0765319804', 'Bucuresti', 'Vintila Mihailescu 12, bl. 79, ap. 89, sc. B, et. 5', 'netbanking', 'Logo - Ferma (1), IlustraÈ›ie Manga (3), Fanart - Genshin I(2), Logo(1)', '950', '2021-07-07 12:08:46', 6),
(12, 'Paula Bicu', 'alina_bicu04@yahoo.com', '0765319804', 'Bucuresti', 'Vintila Mihailescu 12, bl. 79, ap. 89, sc. B, et. 5', 'cards', 'Logo - Ferma (1), Fanart - Genshin I(1)', '300', '2021-07-07 12:09:08', 6),
(13, 'Paula Bicu', 'alina_bicu04@yahoo.com', '0765319804', 'Bucuresti', 'Vintila Mihailescu 12, bl. 79, ap. 89, sc. B, et. 5', 'netbanking', 'IlustraÈ›ie Manga (2), Logo - Ferma (1)', '350', '2021-07-07 12:09:25', 6),
(14, 'Paula Bicu', 'alina_bicu04@yahoo.com', '0765319804', 'Bucuresti', 'Vintila Mihailescu 12, bl. 79, ap. 89, sc. B, et. 5', 'cards', 'IlustraÈ›ie Manga (1), Logo - Ferma (1)', '250', '2021-07-07 12:09:52', 6),
(15, 'Abel B', 'abel_b@gmail.com', '0765319804', 'Cluj', 'Aviatiei, nr. 3', 'cod', 'Logo - Ferma (1), IlustraÈ›ie Manga (1)', '250', '2021-07-07 12:36:31', 4),
(16, 'Isaac B', 'isaac_b@yahoo.com', '0765319804', 'Timisoara', 'Str. Mihai Eminescu, nr. 5, bloc. 8, sc. A, et. 2, ap. 15', 'netbanking', 'Fanart - Genshin I(1), IlustraÈ›ie Manga (1)', '250', '2021-07-07 12:37:51', 5),
(17, 'Paula Bicu', 'alina_bicu04@yahoo.com', '0765319804', 'Bucuresti', 'Vintila Mihailescu 12, bl. 79, ap. 89, sc. B, et. 5', 'cards', 'Logo - Ferma (3), IlustraÈ›ie Manga (1)', '550', '2021-07-07 15:31:41', 6),
(18, 'Isaac BB', 'test@yahoo.com', '0765319804', 'Arges', 'Vintila Mihailescu 12, bl. 79, ap. 89, sc. B, et. 5', 'cod', 'Logo - Ferma (1), IlustraÈ›ie Manga(1)', '250', '2021-07-09 12:20:14', 5),
(19, 'Paula Bicu', 'alina_bicu04@yahoo.com', '0765319804', 'BucureÅŸti', 'Vintila Mihailescu 12, bl. 79, ap. 89, sc. B, et. 5', 'netbanking', 'Logo - Ferma (1), Fanart - Genshin Im(1)', '300', '2021-07-13 17:58:53', 6),
(20, 'Testare', 'test@yahoo.com', '0765319804', 'BucureÅŸti', 'Vintila Mihailescu 12, bl. 79, ap. 89, sc. B, et. 5', 'netbanking', 'Fanart - Genshin Im(2), IlustraÈ›ie Manga(2), Logo - Ferma (2)', '800', '2021-07-14 10:55:37', 9),
(21, 'A', 'a@yahoo.com', '2121212', 'Bucuresti', 'a', 'netbanking', 'Fanart - Genshin Im(3)', '450', '2021-07-14 17:44:59', 4);
