
-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id_products` int(11) NOT NULL AUTO_INCREMENT,
  `name_products` varchar(100) NOT NULL,
  `description_products` text NOT NULL,
  `price_products` int(11) NOT NULL,
  `image_products` text NOT NULL,
  `usersId` int(11) NOT NULL,
  PRIMARY KEY (`id_products`),
  KEY `usersId` (`usersId`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id_products`, `name_products`, `description_products`, `price_products`, `image_products`, `usersId`) VALUES
(11, 'IlustraÈ›ie Manga', 'IlustraÈ›ie digitalÄƒ creatÄƒ folosind software-ul Clip Studio Paint', 100, 'https://i.pinimg.com/originals/5b/a4/fd/5ba4fd607b181ca0e36d1b1f34eccb43.jpg', 3),
(12, 'Logo - Ferma ', 'ÃŽn format SVG È™i PNG, pun la dispozÈ›ia dumneavoastrÄƒ una din creaÈ›iile mele.', 150, 'https://99designs-blog.imgix.net/blog/wp-content/uploads/2017/12/attachment_76013383.jpg?auto=format&q=60&fit=max&w=930', 4),
(19, 'Fanart - Genshin Im', 'Ilustratie digitala a personajului Bennet din jocul Genshin Impact. Desen realizat digital folosind programul Clip Studio Paint. Dimensiuni 740x740', 150, 'https://upload-os-bbs.hoyolab.com/upload/2021/02/26/1015537/d16c2a258acd96a04623692308dd288d_9193833608002301649.jpg?x-oss-process=image/resize,s_740/quality,q_80/auto-orient,0/interlace,1/format,jpg', 6),
(29, 'Logo', 'Ofer servicii de prelucrare a imaginilor, in special de creare a Logo-urilor.', 200, 'https://99designs-acquisition-frontend.imgix.net/serverless/images/categoryPage/hero/logo-design/02-Jervix.jpg?auto=format&w=300&h=300', 5),
(30, 'Goldfish', 'Ilustratie digitala. Dimensiuni 1100x790', 235, 'https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/c8429833-d3e9-4b8c-b682-a9d9e98b8a44/dcfzu2o-0d156125-a3fa-4cff-a689-d7f6c6098ddb.jpg/v1/fill/w_1024,h_736,q_75,strp/goldfish_by_cushart_dcfzu2o-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NzM2IiwicGF0aCI6IlwvZlwvYzg0Mjk4MzMtZDNlOS00YjhjLWI2ODItYTlkOWU5OGI4YTQ0XC9kY2Z6dTJvLTBkMTU2MTI1LWEzZmEtNGNmZi1hNjg5LWQ3ZjZjNjA5OGRkYi5qcGciLCJ3aWR0aCI6Ijw9MTAyNCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.S4QWDgyYMfzr67fBeyIDvZkZ7T79_iq4_q612gXBFyQ', 4),
(31, 'Cold Snow', 'Una dintre cele mai recente creatii. Dimensiuni 2000x1274px 1.31 MB', 350, 'https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/90b0cf78-3356-43b3-a7a2-8e6bf0e85ef1/dcboj51-35ddd84c-be3f-4cf6-a857-69b2e679f06e.jpg/v1/fill/w_1024,h_653,q_75,strp/cold_snow_by_guweiz_dcboj51-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NjUzIiwicGF0aCI6IlwvZlwvOTBiMGNmNzgtMzM1Ni00M2IzLWE3YTItOGU2YmYwZTg1ZWYxXC9kY2JvajUxLTM1ZGRkODRjLWJlM2YtNGNmNi1hODU3LTY5YjJlNjc5ZjA2ZS5qcGciLCJ3aWR0aCI6Ijw9MTAyNCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.h9it2mOwHqjHSl0bxrxuP7mZ-3CGpS318_l4B9Lve94', 4),
(32, 'Dust', 'Portret realizat digital, dimensiuni 841x855px 571.4 KB', 450, 'https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/90b0cf78-3356-43b3-a7a2-8e6bf0e85ef1/davr5f6-8447d388-8d1a-4348-b79f-7b0c7e8f3d73.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzkwYjBjZjc4LTMzNTYtNDNiMy1hN2EyLThlNmJmMGU4NWVmMVwvZGF2cjVmNi04NDQ3ZDM4OC04ZDFhLTQzNDgtYjc5Zi03YjBjN2U4ZjNkNzMuanBnIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.MnvCdosxXygDqzzpU5oDX4QXa1bVtzEtkOGafqoZRps', 5),
(33, 'Knight Abel', 'Ilustratie digitala. Dimensiuni  3101x3496px 20.35 MB', 235, 'https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/a375e1f7-2fd3-4a88-a589-4cd5f8fc0bc1/de50jx2-915e5efa-ff59-4e08-85ec-af4e9a27449b.png/v1/fill/w_1280,h_1444,q_80,strp/knight_abel_by_paulinebba_de50jx2-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9MTQ0NCIsInBhdGgiOiJcL2ZcL2EzNzVlMWY3LTJmZDMtNGE4OC1hNTg5LTRjZDVmOGZjMGJjMVwvZGU1MGp4Mi05MTVlNWVmYS1mZjU5LTRlMDgtODVlYy1hZjRlOWEyNzQ0OWIucG5nIiwid2lkdGgiOiI8PTEyODAifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6aW1hZ2Uub3BlcmF0aW9ucyJdfQ.GwBdCJXksTendIV0YeXdftjYZ4CRFl6wt2dCdEweeH4', 6),
(34, 'test', '2', 1, 'https://i.pinimg.com/originals/5b/a4/fd/5ba4fd607b181ca0e36d1b1f34eccb43.jpg', 4);
