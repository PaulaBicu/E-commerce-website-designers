
-- --------------------------------------------------------

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `id_services` int(11) NOT NULL AUTO_INCREMENT,
  `name_services` text NOT NULL,
  `description_services` text NOT NULL,
  `price_services` int(11) NOT NULL,
  `image_services` text NOT NULL,
  `usersId` int(11) NOT NULL,
  PRIMARY KEY (`id_services`),
  KEY `usersId` (`usersId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id_services`, `name_services`, `description_services`, `price_services`, `image_services`, `usersId`) VALUES
(5, 'Creare logo personalizat', 'ÃŽmi ofer serviciile de a crea logo-uri personalizate ', 150, 'https://www.logodesign.net/images/illustration-logo.png', 4),
(6, 'test', 'test', 1, 'https://www.logodesign.net/images/illustration-logo.png', 3),
(7, 'test', 'test', 2, 'https://www.logodesign.net/images/illustration-logo.png', 6);
