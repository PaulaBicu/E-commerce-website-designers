
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `usersId` int(11) NOT NULL AUTO_INCREMENT,
  `usersName` varchar(128) NOT NULL,
  `usersEmail` varchar(128) NOT NULL,
  `usersUid` varchar(128) NOT NULL,
  `usersPwd` varchar(128) NOT NULL,
  `level` int(2) DEFAULT '0',
  `usersDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`usersId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`usersId`, `usersName`, `usersEmail`, `usersUid`, `usersPwd`, `level`, `usersDate`) VALUES
(3, 'Joshua Abc', 'joshua2020@yahoo.com', 'Joshua', '$2y$10$OwHgkstMgZHZORnZ29VQZeZg3EWzklBKx5c9TetDfpP888O7hj44u', 0, '2021-07-06 14:48:58'),
(4, 'Abel B', 'abel_b@gmail.com', 'Abel', '$2y$10$Y7HqnaTmW89OUirnsqq22ujJlxR1tvJcpGCwgPnc5Ko3zyxx8b6/m', 0, '2021-07-06 14:48:58'),
(5, 'Isaac B', 'isaac_b@yahoo.com', 'Isaac', '$2y$10$Evmte7QquB4qnwoH0ND9/uvE9oKtfAFMiVKtephlj11RpsNotWtoe', 0, '2021-06-06 14:48:58'),
(6, 'Paula Bicu', 'alina_bicu04@yahoo.com', 'Paula', '$2y$10$CsY9/Aeu0YIlr324SRkcTe2O/qE0qC3z9/aufZWuQ6fe6Bu042uTG', 1, '2021-07-06 14:48:58'),
(7, 'Random1', 'random@yahoo.com', 'Random1', '$2y$10$UMV0Q9Q0hHuK9zWcS2svYeWbPczj8cq/JwGprb1NSPVxvmO/XSIMW', 0, '2021-06-02 14:48:58'),
(8, 'Test', 'test@yahoo.com', 'Test', '$2y$10$1dBm1eKD93dvISaR2EWOfuyMXl7hWtXyuEUcpKQ3K3kZkVM1rP3t2', 0, '2021-07-06 14:48:58'),
(9, 'Testare Test', 'testare@yahoo.cpm', 'Testare', '$2y$10$Zx935HqJQXSXeezbpyAq6.d/pvDzDub5OaiZP.SnrUOHpMgWveFPG', 0, '2021-07-14 10:54:38');
